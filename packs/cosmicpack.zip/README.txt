Создатель/Creator:
T1mKey#4641 (Discord)
https://vk.com/tqmkey (VK)
https://t.me/timikea (Telegram)

Соавторы/Co-authors:
Anorjabri#6996 - текстура флага Лягушкабурга/Lyagushkaburg flag texture
Игроки сервера CosmicBedrock/CosmicBedrock server players - участие в голосованиях за обновления/voting for updates

Условия использования:
 - Вы МОЖЕТЕ использовать CosmicPack на серверах, в видио и т.д. Главное - укажите автора;
 - вы НЕ МОЖЕТЕ позиционировать CosmicPack как собственное творение;
 - вы МОЖЕТЕ использовать CosmicPack как шаблон для создания своих текстурпаков;
 - вы НЕ МОЖЕТЕ выкладывать CosmicPack на какой-либо ресурс без указания автора.

Terms of Use:
 - You CAN on servers, videos, etc. The main thing - specify the author.
 - You CANNOT claim CosmicPack as yours creation.
 - You CAN use CosmicPack as a template for creating your own texturepacks.
 - You CANNOT upload CosmicPack to any resource without crediting the author.

Текстурпак создан для майнкрафт бедрок сервера CosmicBedrock.
The texturepack was created for minecraft bedrock server CosmicBedrock.

Перенес на Java версию :
anorjabri(Discord)